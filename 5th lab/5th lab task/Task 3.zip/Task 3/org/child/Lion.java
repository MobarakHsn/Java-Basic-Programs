package org.child;
import org.parent;
public class Lion extends Mammal
{
	protected boolean Bipolar;
	
	public void isBipoloar(boolean Bipolar)
	{
		this.Bipolar=Bipolar;
	}
	
	public boolean isBipolar()
	{
		return Bipolar;
	}
}