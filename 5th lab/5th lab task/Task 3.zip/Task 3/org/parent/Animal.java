package org.parent;
public class Animal
{
	protected double height;
	protected double weight;
	protected String color;
	
	public void setHeight(double height)
	{
		this.height=height;
	}
	
	public double getHeight()
	{
		return height;
	}
	
	public void setWeight(double weight)
	{
		this.weight=weight;
	}
	
	public double getWeight()
	{
		return weight;
	}
	
	public void setColor(String color)
	{
		this.color=color;
	}
	
	public String getColor()
	{
		return color;
	}
}