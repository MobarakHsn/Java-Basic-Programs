import org.*;
public class Main
{
	public static void main(String arg[])
	{
		Animal a=new Animal();
		Mammal m=new Mammal();
		Reptile r=new Reptile();

	}
}